<?php
	require_once('../config.php');
	require_once('../functions.php');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title></title>

    <link rel="stylesheet" href="includes/styles/style.css">

</head>
<body>
	<div class="wrapper">

	</div>
</body>

	<script src="includes/scripts/js/jquery-3.3.1.slim.min.js"></script>
    <script src="includes/scripts/js/script.js"></script>
</html>

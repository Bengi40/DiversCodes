<?php
	require_once('config.php');
	require_once('functions.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../../../favicon.ico">

    <title></title>

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="includes/styles/bootstrap.min.css">
	<link rel="stylesheet" href="includes/styles/style.css">
</head>
<body>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="includes/scripts/js/jquery-3.3.1.slim.min.js"></script>
    <script src="includes/scripts/js/bootstrap.min.js"></script>
    <script src="includes/scripts/js/script.js"></script>

</body>
</html>

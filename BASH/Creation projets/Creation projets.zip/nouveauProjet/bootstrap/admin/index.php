<!DOCTYPE html>
<html>
<head>
    <title>CV Benjamin</title>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="includes/styles/bootstrap.min.css" rel="stylesheet"/>
    <link href="../includes/styles/style.css" rel="stylesheet" type="text/css" >
</head>

<body>

</body>

	<script src="includes/scripts/js/jquery-3.3.1.slim.min.js"></script>
	<script src="includes/scripts/js/bootstrap.min.js"></script>
</html>
